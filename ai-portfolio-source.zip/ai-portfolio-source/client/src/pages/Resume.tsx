import { motion } from "framer-motion";
import { Download, Eye, FileText } from "lucide-react";
import ScrollReveal from "@/components/ScrollReveal";

export default function Resume() {
  const resumeUrl = "/resume.pdf";

  return (
    <div className="min-h-screen">
      {/* Hero — asymmetric */}
      <section className="py-24 lg:py-32">
        <div className="container">
          <div className="max-w-3xl">
            <ScrollReveal>
              <span className="text-gold text-sm font-display tracking-[0.2em] uppercase">
                Resume
              </span>
              <h1 className="mt-4 text-4xl lg:text-5xl xl:text-6xl font-display font-bold text-white leading-[1.1]">
                Professional Resume
              </h1>
              <p className="mt-6 text-muted-foreground text-lg leading-relaxed max-w-xl">
                Download or preview my latest resume to review qualifications,
                experience, and technical skills.
              </p>
            </ScrollReveal>
          </div>
        </div>
      </section>

      {/* Resume Actions — asymmetric */}
      <section className="pb-24">
        <div className="container">
          <div className="grid lg:grid-cols-5 gap-8">
            <div className="lg:col-span-3">
              <ScrollReveal>
                <div className="p-8 rounded-xl border border-white/5 bg-card">
                  <div className="flex items-start gap-5">
                    <div className="w-14 h-14 rounded-lg bg-gold/10 flex items-center justify-center flex-shrink-0">
                      <FileText size={24} className="text-gold" />
                    </div>
                    <div>
                      <h3 className="text-xl font-display font-semibold text-white">
                        AI Full-Stack Engineer
                      </h3>
                      <p className="text-muted-foreground text-sm mt-2 leading-relaxed">
                        Senior AI Engineer with expertise in LLM-powered systems,
                        full-stack development, and scalable architecture.
                        Specializing in production-grade AI applications and
                        enterprise systems.
                      </p>

                      <div className="mt-6 flex flex-col sm:flex-row gap-3">
                        <a
                          href={resumeUrl}
                          download="Resume-AI-Engineer.pdf"
                          className="group inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-gold text-background font-display font-semibold text-sm transition-all duration-300 hover:bg-gold-soft hover:glow-gold-strong"
                        >
                          <Download size={14} />
                          Download PDF
                        </a>
                        <a
                          href={resumeUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg border border-gold/30 text-gold font-display font-medium text-sm transition-all duration-300 hover:bg-gold/10"
                        >
                          <Eye size={14} />
                          Preview
                        </a>
                      </div>
                    </div>
                  </div>
                </div>
              </ScrollReveal>
            </div>

            {/* Stats — right column */}
            <div className="lg:col-span-2">
              <div className="grid grid-cols-2 gap-3">
                {[
                  { label: "Experience", value: "5+" },
                  { label: "Projects", value: "20+" },
                  { label: "Technologies", value: "25+" },
                  { label: "Publications", value: "3" },
                ].map((stat, i) => (
                  <ScrollReveal key={i} delay={i * 0.08}>
                    <motion.div
                      initial={{ opacity: 0, y: 15 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      viewport={{ once: true }}
                      transition={{ duration: 0.4, delay: i * 0.1 }}
                      className="p-4 rounded-lg border border-white/5 bg-card text-center h-full"
                    >
                      <p className="text-2xl font-display font-bold text-gold">
                        {stat.value}
                      </p>
                      <p className="text-[11px] text-muted-foreground mt-1 uppercase tracking-wider">
                        {stat.label}
                      </p>
                    </motion.div>
                  </ScrollReveal>
                ))}
              </div>

              <ScrollReveal delay={0.3}>
                <div className="mt-4 p-5 rounded-lg border border-gold/10 bg-gold/[0.02]">
                  <p className="text-xs text-muted-foreground leading-relaxed">
                    For the most current version of my resume, please reach out
                    directly. Updated quarterly with new achievements and
                    projects.
                  </p>
                </div>
              </ScrollReveal>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
