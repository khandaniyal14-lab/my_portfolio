import { motion } from "framer-motion";
import { GraduationCap, Briefcase, Target } from "lucide-react";
import SectionTitle from "@/components/SectionTitle";
import ScrollReveal from "@/components/ScrollReveal";
import AnimatedCard from "@/components/AnimatedCard";
import { experiences, education, skills } from "@/data/site";
import TechBadge from "@/components/TechBadge";

export default function About() {
  const coreCompetencies = Array.from(
    new Set(skills.map((s) => s.category))
  );

  return (
    <div className="min-h-screen">
      {/* Hero */}
      <section className="py-24 lg:py-32">
        <div className="container">
          <div className="max-w-3xl">
            <ScrollReveal>
              <span className="text-gold text-sm font-display tracking-[0.2em] uppercase">
                About
              </span>
              <h1 className="mt-4 text-4xl lg:text-5xl xl:text-6xl font-display font-bold text-white leading-[1.1]">
                Engineering at the Edge of What&apos;s Possible
              </h1>
              <p className="mt-6 text-muted-foreground text-lg leading-relaxed max-w-xl">
                Five years building production AI systems — from transformer
                architectures to scalable cloud infrastructure. Every system I
                ship is designed to last.
              </p>
            </ScrollReveal>
          </div>
        </div>
      </section>

      {/* Professional Summary — asymmetric 2-column */}
      <section className="pb-16">
        <div className="container">
          <div className="grid lg:grid-cols-5 gap-12">
            <div className="lg:col-span-3">
              <ScrollReveal>
                <h2 className="text-xs font-display tracking-[0.2em] uppercase text-gold mb-6">
                  Profile
                </h2>
                <div className="space-y-5 text-muted-foreground leading-relaxed">
                  <p>
                    I architect and build intelligent systems that operate at
                    production scale. My work spans the full spectrum — from
                    designing custom transformer models and autonomous agent
                    frameworks to shipping cloud-native applications that serve
                    millions of users. I specialize in turning research-grade AI
                    into reliable, scalable engineering.
                  </p>
                  <p>
                    My technical depth covers LLM orchestration, NLP pipelines,
                    distributed systems, and event-driven architectures. I build
                    with PyTorch, LangChain, FastAPI, React, and Kubernetes —
                    technologies I've stress-tested across enterprise
                    deployments and startup environments alike.
                  </p>
                  <p>
                    Beyond engineering, I write, speak, and mentor. I believe
                    that the best AI systems emerge from the intersection of
                    deep technical rigor and sharp product intuition — and that
                    knowledge compounds when shared.
                  </p>
                </div>
              </ScrollReveal>
            </div>

            {/* Career Goals — right column */}
            <div className="lg:col-span-2">
              <ScrollReveal delay={0.15}>
                <AnimatedCard glow className="h-full">
                  <div className="flex items-center gap-3 mb-6">
                    <Target size={16} className="text-gold" />
                    <h3 className="text-sm font-display font-semibold text-white tracking-wide uppercase">
                      Objectives
                    </h3>
                  </div>
                  <ul className="space-y-4 text-sm text-muted-foreground">
                    {[
                      "Lead AI engineering teams at companies pushing boundaries",
                      "Contribute to open-source AI infrastructure",
                      "Build systems that solve critical problems at scale",
                      "Mentor engineers entering the AI field",
                      "Advance autonomous agent architectures",
                    ].map((goal, i) => (
                      <li key={i} className="flex items-start gap-3">
                        <span className="text-gold mt-1 text-[10px] font-mono">
                          {String(i + 1).padStart(2, "0")}
                        </span>
                        {goal}
                      </li>
                    ))}
                  </ul>
                </AnimatedCard>
              </ScrollReveal>
            </div>
          </div>
        </div>
      </section>

      {/* Core Competencies — asymmetric */}
      <section className="py-20 bg-surface">
        <div className="container">
          <div className="flex items-center gap-3 mb-10">
            <span className="text-gold text-xs font-display tracking-[0.2em] uppercase">
              Competencies
            </span>
            <div className="flex-1 h-px bg-gradient-to-r from-gold/30 to-transparent" />
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-5">
            {coreCompetencies.map((cat, i) => {
              const catSkills = skills.filter((s) => s.category === cat);
              return (
                <ScrollReveal key={cat} delay={i * 0.08}>
                  <div className="p-5 rounded-lg border border-white/5 bg-card h-full">
                    <h4 className="text-xs font-display font-medium text-gold tracking-wider uppercase mb-4">
                      {cat}
                    </h4>
                    <div className="flex flex-wrap gap-1.5">
                      {catSkills.map((s) => (
                        <TechBadge key={s.name} name={s.name} />
                      ))}
                    </div>
                  </div>
                </ScrollReveal>
              );
            })}
          </div>
        </div>
      </section>

      {/* Experience — asymmetric alternating */}
      <section className="py-20">
        <div className="container">
          <div className="flex items-center gap-3 mb-10">
            <Briefcase size={14} className="text-gold" />
            <span className="text-xs font-display tracking-[0.2em] uppercase text-gold">
              Career
            </span>
            <div className="flex-1 h-px bg-gradient-to-r from-gold/30 to-transparent" />
          </div>

          <div className="space-y-8">
            {experiences.map((exp, i) => (
              <ScrollReveal key={i} delay={i * 0.1}>
                <motion.div
                  className="grid lg:grid-cols-4 gap-6 p-6 rounded-xl border border-white/5 bg-card hover:border-gold/10 transition-all duration-300"
                  whileHover={{ x: 4 }}
                >
                  <div className="lg:col-span-1">
                    <span className="text-xs text-muted-foreground font-mono">
                      {exp.period}
                    </span>
                    <p className="mt-1 text-gold font-display font-medium text-sm">
                      {exp.company}
                    </p>
                  </div>
                  <div className="lg:col-span-3">
                    <h3 className="text-lg font-display font-semibold text-white mb-2">
                      {exp.role}
                    </h3>
                    <p className="text-muted-foreground text-sm leading-relaxed mb-4">
                      {exp.description}
                    </p>
                    <ul className="space-y-1.5">
                      {exp.highlights.map((h, j) => (
                        <li
                          key={j}
                          className="text-sm text-muted-foreground flex items-start gap-2"
                        >
                          <span className="text-gold mt-1">—</span>
                          {h}
                        </li>
                      ))}
                    </ul>
                  </div>
                </motion.div>
              </ScrollReveal>
            ))}
          </div>
        </div>
      </section>

      {/* Education */}
      <section className="py-20 bg-surface">
        <div className="container">
          <div className="flex items-center gap-3 mb-10">
            <GraduationCap size={14} className="text-gold" />
            <span className="text-xs font-display tracking-[0.2em] uppercase text-gold">
              Education
            </span>
            <div className="flex-1 h-px bg-gradient-to-r from-gold/30 to-transparent" />
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            {education.map((edu, i) => (
              <ScrollReveal key={i} delay={i * 0.1}>
                <div className="p-6 rounded-xl border border-white/5 bg-card h-full">
                  <span className="text-xs text-muted-foreground font-mono">
                    {edu.period}
                  </span>
                  <h3 className="mt-2 text-lg font-display font-semibold text-white">
                    {edu.degree}
                  </h3>
                  <p className="text-gold font-medium text-sm">{edu.institution}</p>
                  <p className="mt-3 text-muted-foreground text-sm leading-relaxed">
                    {edu.description}
                  </p>
                </div>
              </ScrollReveal>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
