import type { Experience, Education } from "@/types";

export const skills = [
  { name: "Python", level: 95, category: "Languages", icon: "python" },
  { name: "TypeScript", level: 92, category: "Languages", icon: "typescript" },
  { name: "React", level: 90, category: "Frontend", icon: "react" },
  { name: "Next.js", level: 88, category: "Frontend", icon: "nextjs" },
  { name: "FastAPI", level: 90, category: "Backend", icon: "fastapi" },
  { name: "Node.js", level: 85, category: "Backend", icon: "nodejs" },
  { name: "PyTorch", level: 88, category: "AI/ML", icon: "pytorch" },
  { name: "TensorFlow", level: 82, category: "AI/ML", icon: "tensorflow" },
  { name: "LangChain", level: 90, category: "AI/ML", icon: "langchain" },
  { name: "OpenAI API", level: 92, category: "AI/ML", icon: "openai" },
  { name: "PostgreSQL", level: 85, category: "Database", icon: "postgresql" },
  { name: "Redis", level: 80, category: "Database", icon: "redis" },
  { name: "Docker", level: 88, category: "DevOps", icon: "docker" },
  { name: "Kubernetes", level: 82, category: "DevOps", icon: "kubernetes" },
  { name: "AWS", level: 85, category: "Cloud", icon: "aws" },
  { name: "GCP", level: 80, category: "Cloud", icon: "gcp" },
];

export const experiences: Experience[] = [
  {
    company: "Tech Innovation Labs",
    role: "Senior AI Full-Stack Engineer",
    period: "2023 — Present",
    description:
      "Leading the development of enterprise-grade AI systems, architecting scalable ML pipelines, and building production-ready applications that serve millions of users.",
    highlights: [
      "Architected a multi-agent AI system reducing manual operations by 70%",
      "Built real-time NLP pipelines processing 50K+ documents daily",
      "Led a team of 6 engineers delivering 3 major product launches",
      "Reduced infrastructure costs by 40% through optimization",
    ],
  },
  {
    company: "DataDriven Solutions",
    role: "AI Engineer",
    period: "2021 — 2023",
    description:
      "Developed machine learning models and full-stack applications for data analytics and automation platforms serving enterprise clients.",
    highlights: [
      "Built automated ML pipelines with 95% model deployment success rate",
      "Developed real-time recommendation engines for e-commerce platforms",
      "Implemented CI/CD pipelines reducing deployment time by 60%",
    ],
  },
  {
    company: "StartupAI",
    role: "Full-Stack Developer",
    period: "2019 — 2021",
    description:
      "Early-stage startup experience building AI-powered SaaS products from zero to production, handling the full technology stack.",
    highlights: [
      "Built the entire platform from scratch — frontend, backend, and ML models",
      "Implemented real-time data processing with sub-second latency",
      "Grew platform from 0 to 10,000 active users",
    ],
  },
];

export const education: Education[] = [
  {
    institution: "Massachusetts Institute of Technology",
    degree: "M.S. in Computer Science — Artificial Intelligence",
    period: "2017 — 2019",
    description:
      "Specialized in deep learning, natural language processing, and distributed systems. Published research on transformer architectures.",
  },
  {
    institution: "University of California, Berkeley",
    degree: "B.S. in Computer Science",
    period: "2013 — 2017",
    description:
      "Dean's List, graduated with honors. Focus on algorithms, machine learning, and software engineering.",
  },
];

export const navLinks = [
  { label: "Home", href: "/" },
  { label: "Projects", href: "/projects" },
  { label: "About", href: "/about" },
  { label: "Resume", href: "/resume" },
  { label: "Contact", href: "/contact" },
];
