import type { Project } from "@/types";

export const projects: Project[] = [
  {
    id: "1",
    slug: "hr-ai-agent",
    featured: true,
    title: "HR AI Agent",
    shortDescription:
      "An intelligent recruitment automation system powered by LLMs that screens candidates, conducts initial interviews, and generates comprehensive hiring reports.",
    longDescription:
      "A comprehensive AI-powered HR automation platform that transforms the recruitment pipeline. The system uses advanced NLP models to parse resumes, conduct structured phone screenings via voice AI, evaluate cultural fit, and generate detailed candidate comparison reports. Built for enterprise HR teams looking to reduce time-to-hire by 60%.",
    technologies: [
      "Python",
      "FastAPI",
      "React",
      "OpenAI API",
      "PostgreSQL",
      "Redis",
      "Docker",
      "LangChain",
      "Pinecone",
      "AWS",
    ],
    coverImage: "/manus-storage/project-hr-ai_d949a7ce.png",
    screenshots: [
      "/manus-storage/project-hr-ai_d949a7ce.png",
      "/manus-storage/project-hr-ai_d949a7ce.png",
      "/manus-storage/project-hr-ai_d949a7ce.png",
    ],
    github: "https://github.com",
    liveDemo: "https://example.com",
    features: [
      "Automated resume parsing with 95% accuracy using custom NER models",
      "AI-powered phone screening with natural conversation flow",
      "Multi-dimensional candidate scoring across 12 evaluation criteria",
      "Real-time dashboard with hiring pipeline analytics",
      "Integration with LinkedIn, Indeed, and Greenhouse ATS",
      "Automated rejection/advancement emails with personalized feedback",
    ],
    challenges: [
      {
        challenge:
          "Handling diverse resume formats across 50+ file types and layouts",
        solution:
          "Built a multi-stage parsing pipeline combining OCR, layout analysis, and LLM-based extraction to achieve consistent structured output regardless of input format.",
      },
      {
        challenge:
          "Maintaining natural conversation flow during AI phone screenings",
        solution:
          "Implemented a state machine with context windows and sentiment tracking to ensure the AI agent adapts its questioning strategy based on candidate responses and emotional cues.",
      },
    ],
    lessonsLearned: [
      "Multi-agent architectures are essential for complex workflows — a single monolithic LLM call cannot handle nuanced recruitment scenarios.",
      "Data quality in training datasets matters more than model size for domain-specific tasks.",
      "User trust in AI systems requires transparent decision explanations, not just accurate predictions.",
    ],
    aiWorkflow: [
      "Resume Upload & Parsing → Document structure analysis with OCR and NER extraction",
      "Skill Matching → Semantic similarity search against job requirements using vector embeddings",
      "Initial Screening → AI phone conversation with structured evaluation rubric",
      "Score Generation → Multi-dimensional scoring across technical, cultural, and experience factors",
      "Report Creation → Automated comprehensive candidate comparison report generation",
    ],
    architectureImage: "/manus-storage/project-hr-ai_d949a7ce.png",
  },
  {
    id: "2",
    slug: "nlp-document-analyzer",
    featured: true,
    title: "NLP Document Analyzer",
    shortDescription:
      "Enterprise-grade NLP pipeline for automated document classification, sentiment analysis, entity extraction, and summarization across large document corpora.",
    longDescription:
      "A scalable natural language processing platform designed for enterprise document management. The system processes thousands of documents daily, performing classification, named entity recognition, sentiment analysis, and abstractive summarization. Features a real-time streaming pipeline with incremental learning capabilities.",
    technologies: [
      "Python",
      "PyTorch",
      "Hugging Face Transformers",
      "FastAPI",
      "React",
      "Elasticsearch",
      "Apache Kafka",
      "Kubernetes",
      "GCP",
      "spaCy",
    ],
    coverImage: "/manus-storage/project-nlp_dbf8b9a9.png",
    screenshots: [
      "/manus-storage/project-nlp_dbf8b9a9.png",
      "/manus-storage/project-nlp_dbf8b9a9.png",
    ],
    github: "https://github.com",
    liveDemo: "https://example.com",
    features: [
      "Automated document classification with 200+ categories",
      "Real-time named entity recognition across 15 entity types",
      "Multi-language sentiment analysis supporting 30+ languages",
      "Abstractive summarization with configurable detail levels",
      "Streaming ingestion pipeline processing 10K+ docs/hour",
      "Interactive visualization dashboard with document relationship graphs",
    ],
    challenges: [
      {
        challenge:
          "Processing documents in 30+ languages with consistent accuracy",
        solution:
          "Deployed language-specific transformer models with a routing layer that detects language and routes to optimized models, maintaining 92%+ accuracy across all supported languages.",
      },
      {
        challenge:
          "Scaling the pipeline to handle 10,000+ documents per hour with low latency",
        solution:
          "Implemented a Kafka-based event-driven architecture with horizontal pod auto-scaling on Kubernetes, achieving sub-second processing times with 99.9% uptime.",
      },
    ],
    lessonsLearned: [
      "Fine-tuning on domain-specific data yields better results than using larger general-purpose models.",
      "Streaming architectures are essential for real-time NLP — batch processing creates unacceptable latency for enterprise workflows.",
      "Model explainability is as important as accuracy when stakeholders need to trust automated document decisions.",
    ],
    aiWorkflow: [
      "Document Ingestion → Multi-format parsing (PDF, DOCX, HTML, images with OCR)",
      "Language Detection → Automatic language identification with confidence scoring",
      "Classification → Hierarchical text classification using fine-tuned BERT models",
      "Entity Extraction → NER with custom entity types using spaCy + transformer pipeline",
      "Sentiment Analysis → Multi-aspect sentiment extraction with aspect-level scoring",
      "Summarization → Abstractive summarization using T5/Pegasus with length control",
      "Indexing → Document embedding storage in Elasticsearch for semantic search",
    ],
    architectureImage: "/manus-storage/project-nlp_dbf8b9a9.png",
  },
  {
    id: "3",
    slug: "autonomous-ai-system",
    featured: true,
    title: "Autonomous AI Agent System",
    shortDescription:
      "A multi-agent autonomous system capable of complex task planning, execution, and self-correction using LLM orchestration and tool-use frameworks.",
    longDescription:
      "An advanced autonomous AI system that plans, executes, and self-corrects complex multi-step tasks. The system uses a hierarchical multi-agent architecture with specialized agents for research, coding, data analysis, and decision-making. Features real-time task monitoring, error recovery, and human-in-the-loop escalation.",
    technologies: [
      "Python",
      "LangGraph",
      "OpenAI API",
      "Anthropic Claude",
      "Redis",
      "PostgreSQL",
      "React",
      "WebSocket",
      "Docker",
      "TypeScript",
    ],
    coverImage: "/manus-storage/project-autonomous_587afe83.png",
    screenshots: [
      "/manus-storage/project-autonomous_587afe83.png",
      "/manus-storage/project-autonomous_587afe83.png",
    ],
    github: "https://github.com",
    liveDemo: "https://example.com",
    features: [
      "Hierarchical multi-agent architecture with specialized role agents",
      "Autonomous task decomposition and parallel execution",
      "Self-correction with error detection and recovery mechanisms",
      "Human-in-the-loop escalation for critical decisions",
      "Real-time execution visualization and progress tracking",
      "Tool-use framework with 50+ pre-built integrations",
      "Memory persistence across sessions with vector storage",
    ],
    challenges: [
      {
        challenge:
          "Coordinating multiple LLM agents without conflicting outputs or redundant work",
        solution:
          "Designed a shared memory architecture with lock-free state management and a consensus protocol for agent outputs, ensuring coherent multi-agent collaboration.",
      },
      {
        challenge:
          "Handling infinite loops and task failures gracefully in autonomous execution",
        solution:
          "Implemented a multi-layer safety system with execution budgets, divergence detection, and progressive escalation — from self-correction to human review to task termination.",
      },
    ],
    lessonsLearned: [
      "Autonomous systems need explicit stopping criteria — LLMs will always attempt to continue without clear termination conditions.",
      "Multi-agent communication overhead grows exponentially — graph-based routing is more efficient than peer-to-peer messaging.",
      "The most critical component of autonomous AI is not the LLM but the orchestration layer that manages state, context, and error recovery.",
    ],
    aiWorkflow: [
      "Task Analysis → Deconstruct complex tasks into executable sub-tasks using LLM planning",
      "Agent Selection → Route sub-tasks to specialized agents based on capability matching",
      "Parallel Execution → Coordinate multi-agent execution with dependency-aware scheduling",
      "Result Synthesis → Merge agent outputs with conflict resolution and validation",
      "Self-Correction → Detect errors, retry with alternative strategies, or escalate to human",
    ],
    architectureImage: "/manus-storage/project-autonomous_587afe83.png",
  },
];
